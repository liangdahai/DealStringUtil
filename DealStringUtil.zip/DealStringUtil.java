
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.*;

public class DealStringUtil {

    public static void main(String[] args) {
        String input = "aabcccbbad";
        //stage1:remove string
        stage1(input);
        //stage2:replace string
        stage2(input);
    }

    public static void stage1(String input) {
        String current = input;
        AtomicBoolean changed = new AtomicBoolean(false);

        do {
            final String s = current;
            StringBuilder sb = new StringBuilder();
            changed.set(false);
            int[] lastIndex = {0};

            IntStream.range(0, s.length())
                    .filter(i -> i == s.length() - 1 || s.charAt(i) != s.charAt(i + 1))
                    .forEach(i -> {
                        int length = i - lastIndex[0] + 1;
                        if (length < 3) {
                            sb.append(s.substring(lastIndex[0], i + 1));
                        } else {
                            changed.set(true);
                        }
                        lastIndex[0] = i + 1;
                    });

            if (changed.get()) {
                current = sb.toString();
                System.out.println("-> " + current);
            }

        } while (changed.get());
    }

    private static void stage2(String input){
        List<String> steps = new ArrayList<>();
        process(input, steps);
        for (String step : steps) {
            System.out.println(step);
        }
    }
    private static void process(String s, List<String> steps) {
        while (true) {
            String newStr = processStep(s, steps);
            if (newStr == null) {
                break;
            }
            s = newStr;
        }
    }

    private static String processStep(String s, List<String> steps) {
        int n = s.length();
        if (n < 3) {
            return null;
        }

        for (int i = 0; i <= n - 3; i++) {
            char current = s.charAt(i);
            if (s.charAt(i + 1) == current && s.charAt(i + 2) == current) {
                int j = i + 3;
                while (j < n && s.charAt(j) == current) {
                    j++;
                }
                int end = j - 1;

                char replaceChar = (i > 0) ? s.charAt(i - 1) : '\0';

                String newStr;
                if (i > 0) {
                    newStr = s.substring(0, i) + replaceChar + s.substring(end + 1);
                } else {
                    newStr = s.substring(end + 1);
                }

                // ������������
                String replaced = s.substring(i, end + 1);
                String step;
                if (i > 0) {
                    step = String.format("->%s��%s is replaced by %c", newStr, replaced, replaceChar);
                } else {
                    step = String.format("->%s", newStr);
                }
                steps.add(step);

                return newStr;
            }
        }
        return null;
    }
}